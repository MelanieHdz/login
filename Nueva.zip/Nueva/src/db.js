import mongoose from "mongoose";

export const connectDB= async()=>{
    try{
        await mongoose.connect("mongodb://localhost/pruebacrud");
            console.log("DB Conectada");
    } catch(error){
        console.log(error);
    }
};